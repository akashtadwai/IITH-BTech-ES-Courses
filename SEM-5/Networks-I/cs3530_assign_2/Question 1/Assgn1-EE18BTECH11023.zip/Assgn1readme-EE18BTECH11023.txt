Instructions:

1. Navigate to the folder containing the code file and run the following command.
2. $ gcc Asgn1Src-EE18BTECH11023.c -o collatz -lpthread
3. To execute the file type,
    $ ./collatz <num>
    where <num> is any number greater than 0.