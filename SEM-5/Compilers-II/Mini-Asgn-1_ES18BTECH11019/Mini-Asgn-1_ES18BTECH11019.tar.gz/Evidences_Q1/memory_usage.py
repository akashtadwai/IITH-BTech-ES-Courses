if __name__ == "__main__":
    a = 4
    for i in range(20):
        a += 4
    print(a)
# The value of 'a' is directly printed on console no intermediate files are generated.
