#include <bits/stdc++.h>
using namespace std;
int main() {
  int a = 4;
  for (int i = 0; i < 20; i++)
    a += 4;
  cout << a << endl;
//   When we compile this file we get a *.out file which is executable and hence some 
// memory is required
}