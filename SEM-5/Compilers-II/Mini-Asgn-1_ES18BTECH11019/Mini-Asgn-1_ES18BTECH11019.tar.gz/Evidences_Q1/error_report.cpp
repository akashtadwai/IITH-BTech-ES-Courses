#include <bits/stdc++.h>
using namespace std;

int main() {
  // Program displaying multiple error messages
  int a = 0;
  while (a < 10
     a++
 cout << "This is an error too as statement is not ended."
  /*All the errors in line 7,8 and 9 are reported as errors thus compiler scans
  the whole file for reporting errors*/
}