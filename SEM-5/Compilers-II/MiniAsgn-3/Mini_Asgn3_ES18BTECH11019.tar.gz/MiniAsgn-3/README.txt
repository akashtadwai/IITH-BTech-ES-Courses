Compilation Instructions:

    $ yacc -d <file_name>.y
    $ lex method1.l
    $ cc lex.yy.c y.tab.c 

All the three files have same lexical input.

To execute the code and give input type ./a.out and give the input number.
Appropriate error or the decimal equivalent of the binary will be printed.
