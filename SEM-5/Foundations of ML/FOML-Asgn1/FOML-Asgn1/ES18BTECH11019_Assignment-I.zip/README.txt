
Compilation Instructions:

    For the Programming questions directly goto the Google Colab and click Runtime-> Run all to Run all the Cells.
    All the Plots and Derivations are also mentioned in Colab Notebooks.

    1. Q3:  https://colab.research.google.com/drive/1RIH4N19g8it21CmKt_tUkKTUPszNoOGc?usp=sharing
    2. Q4: https://colab.research.google.com/drive/13H5d6ahvjZSX75n3Lm-WQh5V6Pe4IM3P?usp=sharing

    NOTE: To run on a local Machine please makesure to have all the necessary ML packages such as Numpy, Pandas, MatplotLib and Seaborn.
          It is better to run the code in Google Colab.


-> We have reported all our Observations and Conclusions in Report.pdf and all the realated TEX files are in main.tex and pictures/ directory.

-> To view and compile Tex online,visit https://www.overleaf.com/read/vddfhzgctpvn 
