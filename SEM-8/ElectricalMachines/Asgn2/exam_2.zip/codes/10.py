from para3 import *

v1 = 200
v2 = 380
k = v2 / v1
ro2 = wsc / (isc ** 2)
ro1 = ro2 / (k ** 2)
print(ro1)
