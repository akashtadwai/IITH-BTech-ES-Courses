from para2 import *

print(i)
