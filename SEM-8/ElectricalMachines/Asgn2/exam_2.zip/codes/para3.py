wsc = 98
isc = 8
vsc = 16

woc = 50
voc = 200
ioc = 0.7
