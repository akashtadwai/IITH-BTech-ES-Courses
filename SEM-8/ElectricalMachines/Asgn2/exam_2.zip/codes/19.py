from para2 import *

print(vs)
