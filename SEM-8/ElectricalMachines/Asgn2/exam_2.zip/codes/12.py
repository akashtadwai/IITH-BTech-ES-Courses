from para3 import *
import math

z = (wsc) / (isc ** 2)
r = vsc / isc
ans = math.sqrt(r ** 2 - z ** 2)
print(ans)
