from para1 import *

ans = if2
print(ans)
