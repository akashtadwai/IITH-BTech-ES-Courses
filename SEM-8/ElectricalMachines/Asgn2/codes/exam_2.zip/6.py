from para1 import *

ans = v2
print(ans)
