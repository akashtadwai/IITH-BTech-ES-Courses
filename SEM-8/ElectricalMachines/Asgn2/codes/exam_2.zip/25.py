flp = 1520
fraction = 1 / 2
hll = (fraction ** 2) * flp
print(hll)
