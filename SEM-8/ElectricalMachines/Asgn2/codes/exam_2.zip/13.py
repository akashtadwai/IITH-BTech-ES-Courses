from para3 import *

temp = woc / voc
ans = voc / temp
print(ans)
