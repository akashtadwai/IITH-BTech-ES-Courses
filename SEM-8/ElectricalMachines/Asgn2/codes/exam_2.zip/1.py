ratio = 13 / 125
v1 = 210
v2 = v1 / ratio
r = 10000
ans = v2 ** 2 / r
print(ans)
