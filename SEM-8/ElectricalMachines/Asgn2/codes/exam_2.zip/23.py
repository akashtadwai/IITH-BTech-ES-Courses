wo = 5000
vo = 200
io = 79
pf = wo / (vo * io)
ans = io * pf
print(ans)
