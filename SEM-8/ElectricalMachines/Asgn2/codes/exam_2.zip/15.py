v1 = 200
v2 = 90
p = 430
i = 3
ans = p / (v1 * i)
print(ans)
