n1 = 380
n2 = 40
v1 = 2570
kva = int(2 * 1e4)
v2 = v1 * (n2 / n1)
if1 = kva / v1
if2 = kva / v2
f = 50
