from para1 import *

ans = v1 / (4.44 * f * n1)
print(ans)
