from para2 import *

print(power)
