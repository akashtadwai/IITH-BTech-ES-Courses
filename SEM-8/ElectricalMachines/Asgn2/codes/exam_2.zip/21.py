rs = 450
ns = 6
np = 3
ans = (rs * (np ** 2)) / (ns ** 2)
print(ans)
