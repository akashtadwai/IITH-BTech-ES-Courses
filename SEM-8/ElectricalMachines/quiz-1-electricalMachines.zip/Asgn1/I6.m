f=55;
p=6;
Sf=4.95;


S=Sf/f;
%Pcr/Pm
ratio=S/(1-S)