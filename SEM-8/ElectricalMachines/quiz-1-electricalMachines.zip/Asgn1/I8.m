f=65;
p=4;
S=0.04;

Ns=120*f/p;
Nr=(1-S)*Ns