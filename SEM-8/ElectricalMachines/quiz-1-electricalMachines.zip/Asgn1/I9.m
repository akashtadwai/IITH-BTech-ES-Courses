f=40;
S=0.11;

femf=S*f