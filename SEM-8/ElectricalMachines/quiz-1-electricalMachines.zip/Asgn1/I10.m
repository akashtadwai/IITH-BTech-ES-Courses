R2=0.011;
X2=0.05;

required=X2-R2