f=40;
p=8;
Nfl=576;

Ns=120*f/p;

sfl=(Ns-Nfl)/Ns
