f=40;
p=4;
P2=16500;
Pcuphase=275;
Pcr=Pcuphase*3;

Ns=120*f/p;
S=Pcr/P2;

%rotor spped
Nr=(1-S)*Ns